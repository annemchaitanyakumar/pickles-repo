// Rewritten TokenService (no experimental class fields) - stable for Vite import analysis
class TokenService {
  constructor() {
    this.TOKEN_COOKIE = 'auth_token';
    this.USER_DATA_KEY = 'authData';
    this.USER_COOKIE_PREFIX = 'htp_user_';

    this.USER_FIELDS = [
      'emailid',
      'firstname',
      'lastname',
      'mobilenum',
      'role',
      'userId',
      'userid'
    ];

    this._hasSession = false;
    this.accessToken = null;
    this._autoRefreshTimer = null;

    console.log('[TokenService] Initializing');
    this.init();
  }

  async init() {
    try {
      const userData = localStorage.getItem(this.USER_DATA_KEY);
      const parsedUserData = userData ? JSON.parse(userData) : null;
      console.log('[TokenService] init userData:', parsedUserData);

      const hasRecentSession = parsedUserData && parsedUserData.lastRefresh &&
        (Date.now() - parsedUserData.lastRefresh) < 12 * 60 * 60 * 1000;

      const hasUserHint = hasRecentSession || (document.cookie || '').includes(this.USER_COOKIE_PREFIX);

      if (hasUserHint) {
        try {
          const token = await this.refreshToken();
          if (token) {
            console.log('[TokenService] Silent refresh on init succeeded');
            if (typeof window !== 'undefined') {
              window.dispatchEvent(new CustomEvent('auth:token-refreshed', { detail: { success: true } }));
            }
          }
        } catch (err) {
          console.warn('[TokenService] Silent refresh on init failed:', err);
        }
      } else {
        console.log('[TokenService] No session hint found on init — skipping silent refresh');
      }

      if (typeof window !== 'undefined') {
        let visTimeout = null;
        window.addEventListener('visibilitychange', () => {
          if (document.visibilityState === 'visible') {
            if (visTimeout) clearTimeout(visTimeout);
            visTimeout = setTimeout(() => {
              if (!this.accessToken || this.willTokenExpireSoon()) {
                this.refreshToken().catch(e => console.warn('[TokenService] visibility refresh failed:', e));
              }
            }, 300);
          }
        });

        window.addEventListener('focus', () => {
          if (!this.accessToken || this.willTokenExpireSoon()) {
            this.refreshToken().catch(e => console.warn('[TokenService] focus refresh failed:', e));
          }
        });
      }
    } catch (err) {
      console.error('[TokenService] Init error:', err);
    }
  }

  setTokens(accessToken, _unused, userData) {
    const token = accessToken ? (accessToken.startsWith('Bearer ') ? accessToken : `Bearer ${accessToken}`) : null;
    console.log('[TokenService] setTokens, received token:', !!token, 'userData:', userData);

    this.accessToken = token;
    this._hasSession = !!token || !!userData;

    if (userData) {
      const existing = this.getUserInfo() || {};
      const mergedForStorage = Object.assign({}, existing, userData, { role: userData.role || existing.role, lastRefresh: Date.now() });
      if (mergedForStorage.accessToken) delete mergedForStorage.accessToken;
      localStorage.setItem(this.USER_DATA_KEY, JSON.stringify(mergedForStorage));

      this.USER_FIELDS.forEach(field => {
        if (mergedForStorage[field] != null) {
          const cookieName = `${this.USER_COOKIE_PREFIX}${field}`;
          const cookieValue = encodeURIComponent(String(mergedForStorage[field]));
          const oneWeek = 7 * 24 * 60 * 60 * 1000;
          const expires = new Date(Date.now() + oneWeek).toUTCString();
          document.cookie = `${cookieName}=${cookieValue}; expires=${expires}; path=/; SameSite=Strict`;
        }
      });
    }

    this.setAutoRefresh();
  }

  getAccessToken() {
    if (this.accessToken && !this.isTokenExpired(this.accessToken)) {
      const pureToken = this.accessToken.startsWith('Bearer ') ? this.accessToken.split(' ')[1] : this.accessToken;
      return `Bearer ${pureToken}`;
    }
    return null;
  }

  isTokenExpired(token) {
    if (!token) return true;
    try {
      const raw = token.startsWith('Bearer ') ? token.split(' ')[1] : token;
      const parts = raw.split('.');
      if (parts.length < 2) return true;
      const payload = JSON.parse(atob(parts[1]));
      return Date.now() >= payload.exp * 1000;
    } catch (e) {
      console.warn('[TokenService] isTokenExpired parse error', e);
      return true;
    }
  }

  willTokenExpireSoon(token) {
    const t = token || this.accessToken;
    if (!t) return true;
    try {
      const raw = t.startsWith('Bearer ') ? t.split(' ')[1] : t;
      const payload = JSON.parse(atob(raw.split('.')[1]));
      const expMs = payload.exp * 1000;
      return (expMs - Date.now()) <= 5 * 60 * 1000;
    } catch (e) {
      console.warn('[TokenService] willTokenExpireSoon parse error', e);
      return true;
    }
  }

  async refreshToken() {
    const MAX_RETRIES = 3;
    const BASE_DELAY = 800;
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      try {
        const res = await this.performRefresh();
        if (res) return res;
      } catch (err) {
        console.warn(`[TokenService] refresh attempt ${attempt + 1} failed`, err);
        if (attempt === MAX_RETRIES - 1) throw err;
        const wait = BASE_DELAY * Math.pow(2, attempt);
        await new Promise(r => setTimeout(r, wait));
      }
    }
    return null;
  }

  async performRefresh() {
    try {
      console.log('[TokenService] performRefresh -> calling /refresh-token (cookie-based)');
      const response = await fetch(`${import.meta.env.VITE_API_URL}/refresh-token`, {
        method: 'POST',
        credentials: 'include'
      });

      const text = await response.text().catch(() => '');
      console.log('[TokenService] refresh status', response.status, 'body:', text);

      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          console.warn('[TokenService] refresh unauthorized (401/403) — refresh failed');
          return null;
        }
        throw new Error(`Refresh failed: ${response.status}`);
      }

      let data = {};
      try { data = JSON.parse(text || '{}'); } catch (e) { console.warn('[TokenService] parse refresh JSON failed', e); }

      if (data.accessToken) {
        const token = data.accessToken.startsWith('Bearer ') ? data.accessToken : `Bearer ${data.accessToken}`;
        const currentUser = this.getUserInfo() || {};
        const updatedUser = Object.assign({}, currentUser, { accessToken: token });
        this.setTokens(token, null, updatedUser);
        console.log('[TokenService] refresh successful, token set');
        return token;
      }

      // If the refresh endpoint returned OK but no accessToken, it may have
      // rotated/extended the HttpOnly refresh cookie (common pattern). In that
      // case, mark that a session exists so subsequent cookie-based requests
      // can succeed even without an Authorization header.
      console.log('[TokenService] refresh endpoint returned OK but no accessToken. Assuming refresh-cookie updated.');
      this._hasSession = true;
      // update lastRefresh timestamp in stored user info
      try {
        const cur = this.getUserInfo() || {};
        const merged = Object.assign({}, cur, { lastRefresh: Date.now() });
        if (Object.keys(merged).length) localStorage.setItem(this.USER_DATA_KEY, JSON.stringify(merged));
      } catch (e) {}
      return true;
    } catch (error) {
      console.error('[TokenService] performRefresh error:', error);
      throw error;
    }
  }

  setAutoRefresh() {
    const token = this.getAccessToken();
    if (!token) return;
    try {
      const raw = token.split(' ')[1];
      const payload = JSON.parse(atob(raw.split('.')[1]));
      const expMs = payload.exp * 1000;
      const timeLeft = expMs - Date.now();
      const refreshDelay = Math.max(timeLeft - 5 * 60 * 1000, 0);

      if (this._autoRefreshTimer) clearTimeout(this._autoRefreshTimer);
      console.log('[TokenService] scheduling auto refresh in ms:', refreshDelay);

      this._autoRefreshTimer = setTimeout(async () => {
        try {
          await this.refreshToken();
        } catch (e) {
          console.warn('[TokenService] auto refresh failed:', e);
        }
      }, refreshDelay);
    } catch (e) {
      console.warn('[TokenService] setAutoRefresh error:', e);
    }
  }

  clearTokens() {
    console.log('[TokenService] Clearing tokens and user data');
    this.accessToken = null;
    localStorage.removeItem(this.USER_DATA_KEY);

    this.USER_FIELDS.forEach(field => {
      const cookieName = `${this.USER_COOKIE_PREFIX}${field}`;
      document.cookie = `${cookieName}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Strict`;
    });

    if (this._hasSession) {
      fetch(`${import.meta.env.VITE_API_URL}/logout`, { method: 'POST', credentials: 'include' })
        .catch(e => console.warn('[TokenService] backend logout error', e));
    }

    this._hasSession = false;

    try {
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('auth:cleared', { detail: { reason: 'cleared' } }));
      }
    } catch (e) {
      console.warn('[TokenService] dispatch auth:cleared failed', e);
    }
  }

  getUserInfo() {
    try {
      const data = localStorage.getItem(this.USER_DATA_KEY);
      const parsed = data ? JSON.parse(data) : {};
      const cookies = (document.cookie || '').split('; ').reduce((acc, kv) => {
        const [k, v] = kv.split('=');
        if (!k) return acc;
        if (k.startsWith(this.USER_COOKIE_PREFIX)) {
          const field = k.replace(this.USER_COOKIE_PREFIX, '');
          acc[field] = decodeURIComponent(v || '');
        }
        return acc;
      }, {});
      const merged = Object.assign({}, cookies, parsed);
      if (Object.keys(merged).length > 0 && typeof window !== 'undefined') {
        try { window.dispatchEvent(new CustomEvent('auth:set', { detail: merged })); } catch (e) {}
        return merged;
      }
      return null;
    } catch (e) {
      console.warn('[TokenService] getUserInfo parse error:', e);
      return null;
    }
  }
}

export const tokenService = new TokenService();
