import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { getAllPromosAdmin, createPromoCodeAdmin, editPromoCodeAdmin, deletePromoCodeAdmin } from '@/services/promoService';
import { Switch } from '@/components/ui/switch';

const PromoManagement = () => {
  const { toast } = useToast();
  const [promos, setPromos] = useState([]);
  const [loading, setLoading] = useState(false);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingPromo, setEditingPromo] = useState(null);
  const [form, setForm] = useState({
    code: '',
    discount_type: 'percent',
    discount_value: '',
    valid_from: '',
    valid_to: '',
    usage_limit: '',
    used_count: 0,
    active: true,
  });

  const loadPromos = async () => {
    setLoading(true);
    try {
      const data = await getAllPromosAdmin();
      setPromos(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error('Failed to load promos', err);
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to load promos' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadPromos(); }, []);

  const openCreate = () => {
    setEditingPromo(null);
    setForm({
      code: '',
      discount_type: 'percent',
      discount_value: '',
      valid_from: '',
      valid_to: '',
      usage_limit: '',
      used_count: 0,
      active: true,
    });
    setDialogOpen(true);
  };

  const openEdit = (promo) => {
    setEditingPromo(promo);
    setForm({
      code: promo.code || '',
      discount_type: promo.discount_type || 'percent',
      discount_value: promo.discount_value || '',
      // assume incoming times are like "2025-09-01 05:30:00" -> convert to input-friendly format later
      valid_from: promo.valid_from ? promo.valid_from.replace(' ', 'T') : '',
      valid_to: promo.valid_to ? promo.valid_to.replace(' ', 'T') : '',
      usage_limit: promo.usage_limit ?? '',
      used_count: promo.used_count ?? 0,
      active: !!promo.active
    });
    setDialogOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
  if (!form.code) throw new Error('Code is required');
  if (!form.discount_value) throw new Error('Discount value is required');
  if (!form.valid_from) throw new Error('Valid from date is required');
  if (!form.valid_to) throw new Error('Valid to date is required');
  if (form.usage_limit === '' || form.usage_limit === null) throw new Error('Usage limit is required');

      // Build payload matching Django expected shape
      const formatDateForBackend = (dt) => {
        if (!dt) return '';
        // dt from input[type=datetime-local] is like '2025-09-01T05:30'
        // convert to 'YYYY-MM-DD HH:MM:SS'
        const v = dt.includes('T') ? dt : dt.replace(' ', 'T');
        const d = new Date(v);
        if (isNaN(d.getTime())) return String(dt).replace('T', ' ');
        const pad = (n) => String(n).padStart(2, '0');
        return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
      };

      const payload = {
        // include id for PATCH requests (some backends expect the id in the body)
        ...(editingPromo ? { id: editingPromo.id || editingPromo.pk || editingPromo.promocode_id } : {}),
        code: String(form.code).trim(),
        discount_type: String(form.discount_type || 'percent'),
        discount_value: String((parseFloat(form.discount_value || 0) || 0).toFixed(2)),
        valid_from: formatDateForBackend(form.valid_from),
        valid_to: formatDateForBackend(form.valid_to),
        // ensure numeric usage_limit (send integer if provided)
        usage_limit: form.usage_limit !== '' && form.usage_limit !== null ? parseInt(form.usage_limit, 10) : null,
        used_count: form.used_count !== undefined ? parseInt(form.used_count, 10) : 0,
        active: !!form.active
      };

      if (editingPromo) {
        const idToUse = editingPromo.id || editingPromo.pk || editingPromo.promocode_id;
        await editPromoCodeAdmin(idToUse, payload);
        toast({ title: 'Updated', description: 'Promo updated' });
      } else {
        await createPromoCodeAdmin(payload);
        toast({ title: 'Created', description: 'Promo created' });
      }
      await loadPromos();
    } catch (err) {
      console.error('Failed to submit promo', err);
      toast({ variant: 'destructive', title: 'Error', description: err.message || 'Failed to submit promo' });
    }
  };

  const handleDelete = async (promo) => {
    if (!promo) return;
    if (!confirm(`Delete promo ${promo.code || promo.id || ''}?`)) return;
    try {
      await deletePromoCodeAdmin(promo.id || promo.pk || promo.promocode_id);
      toast({ title: 'Deleted', description: 'Promo deleted' });
      await loadPromos();
    } catch (err) {
      console.error('Delete promo error', err);
      toast({ variant: 'destructive', title: 'Error', description: err.message || 'Failed to delete promo' });
    }
  };

  return (
    <div className="container mx-auto p-4">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold">Promo Management</h1>
        <Button onClick={openCreate}>Create Promo</Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {loading ? (
          <div>Loading...</div>
        ) : promos.length === 0 ? (
          <div className="text-muted-foreground">No promos found</div>
        ) : (
          promos.map((p) => (
            <Card key={p.id || p.pk || p.promocode_id} className="p-3">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">{p.code}</div>
                    <div className="text-sm text-muted-foreground">Discount: {p.discount_value}</div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm" onClick={() => openEdit(p)}>Edit</Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDelete(p)}>Delete</Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground">Active: {p.active ? 'Yes' : 'No'}</div>
                {p.description && <div className="mt-2 text-sm">{p.description}</div>}
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingPromo ? 'Edit Promo' : 'Create Promo'}</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4 p-2">
            <div>
              <Label>Code</Label>
              <Input value={form.code} onChange={(e) => setForm(prev => ({ ...prev, code: e.target.value }))} />
            </div>
            <div>
              <Label>Discount Value</Label>
              <Input type="number" step="0.01" value={form.discount_value} onChange={(e) => setForm(prev => ({ ...prev, discount_value: e.target.value }))} />
            </div>
            <div>
              <Label>Discount Type</Label>
              <select className="w-full border rounded px-2 py-1" value={form.discount_type} onChange={(e) => setForm(prev => ({ ...prev, discount_type: e.target.value }))}>
                <option value="percent">percent</option>
                <option value="fixed">fixed</option>
              </select>
            </div>
            <div>
              <Label>Valid From</Label>
              <Input type="datetime-local" value={form.valid_from} onChange={(e) => setForm(prev => ({ ...prev, valid_from: e.target.value }))} />
            </div>
            <div>
              <Label>Valid To</Label>
              <Input type="datetime-local" value={form.valid_to} onChange={(e) => setForm(prev => ({ ...prev, valid_to: e.target.value }))} />
            </div>
            <div>
              <Label>Usage Limit</Label>
              <Input type="number" value={form.usage_limit} onChange={(e) => setForm(prev => ({ ...prev, usage_limit: e.target.value }))} />
            </div>
            <div>
              <Label>Used Count</Label>
              <Input type="number" value={form.used_count} onChange={(e) => setForm(prev => ({ ...prev, used_count: e.target.value }))} />
            </div>
            <div className="flex items-center gap-3">
              <Label>Active</Label>
              <Switch checked={form.active} onCheckedChange={(v) => setForm(prev => ({ ...prev, active: !!v }))} />
            </div>

            <DialogFooter className="flex justify-between">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button type="submit">{editingPromo ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PromoManagement;
