import axios from '../lib/axios';

// Get all promo codes
export const getAllPromoCodes = async () => {
    try {
        const response = await axios.get('/getallpromos');
        
        if (Array.isArray(response.data)) {
            // Only transform active promocodes
            return response.data
                .filter(promo => promo.active)
                .map(promo => ({
                    code: promo.code,
                    discount: parseFloat(promo.discount_value)
                }));
        }
        
        console.warn('Unexpected response format from promo API:', response.data);
        return [];
    } catch (error) {
        console.error('Error fetching promo codes:', error);
        return [];
    }
};

// Admin: get full promo objects (no filtering)
export const getAllPromosAdmin = async () => {
    try {
        const response = await axios.get('/getallpromos');
        return response.data || [];
    } catch (error) {
        console.error('Error fetching all promos (admin):', error);
        throw error;
    }
};

// Admin: create a promocode
export const createPromoCodeAdmin = async (payload) => {
    try {
        // Get CSRF token from cookie
        const getCSRFToken = () => {
            const match = document.cookie.match(/csrftoken=([^;]+)/);
            return match ? match[1] : null;
        };
        const csrfToken = getCSRFToken();
        const response = await axios.post('/create-promocode', payload, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                ...(csrfToken ? { 'X-CSRFToken': csrfToken } : {})
            },
            withCredentials: true
        });
        return response.data;
    } catch (error) {
        console.error('Error creating promo code:', error);
        throw error;
    }
};

// Admin: edit promocode
export const editPromoCodeAdmin = async (id, updateFields) => {
    try {
        // Get CSRF token from cookie
        const getCSRFToken = () => {
            const match = document.cookie.match(/csrftoken=([^;]+)/);
            return match ? match[1] : null;
        };
        const csrfToken = getCSRFToken();
        // Include the ID in the payload as Django might expect it
        const payload = {
            ...updateFields,
            id: parseInt(id)
        };
        // Ensure trailing slash to match Django-style endpoints
        const response = await axios.patch(`/promocode/${id}`, payload, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                ...(csrfToken ? { 'X-CSRFToken': csrfToken } : {})
            },
            withCredentials: true
        });
        return response.data;
    } catch (error) {
        console.error('Error editing promo code:', error);
        // Enhanced error handling
        if (error.response?.status === 403) {
            throw new Error('Permission denied. Please ensure you are logged in as an admin.');
        }
        throw error;
    }
};

// Admin: delete promocode
export const deletePromoCodeAdmin = async (id) => {
    try {
        // Get CSRF token from cookie
        const getCSRFToken = () => {
            const match = document.cookie.match(/csrftoken=([^;]+)/);
            return match ? match[1] : null;
        };
        const csrfToken = getCSRFToken();
        const response = await axios.delete(`/promocode/${id}`, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                ...(csrfToken ? { 'X-CSRFToken': csrfToken } : {})
            },
            withCredentials: true
        });
        return response.data;
    } catch (error) {
        console.error('Error deleting promo code:', error);
        throw error;
    }
};

// Apply promo code
export const applyPromoCode = async (code) => {
    try {
        const response = await axios.post(`/apply-promocode?code=${encodeURIComponent(code)}`);
        
        // If the promocode is valid, get its details to show discount
        if (response.data) {
            const detailsResponse = await axios.get('/getallpromos');
            const promoDetails = Array.isArray(detailsResponse.data) 
                ? detailsResponse.data.find(promo => promo.code.toLowerCase() === code.toLowerCase())
                : null;

            if (promoDetails) {
                return {
                    code: promoDetails.code,
                    discount: parseFloat(promoDetails.discount_value)
                };
            }
        }
        throw new Error('Invalid promocode');
    } catch (error) {
        // Handle specific error messages from the backend
        if (error.response?.data) {
            const errorMessage = typeof error.response.data === 'string' 
                ? error.response.data 
                : error.response.data.message;
            throw new Error(errorMessage || 'Failed to apply promocode');
        }
        throw new Error('Failed to apply promocode');
    }
};
