import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils.js';
import '../styles/animations.css';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import {
  Users,
  Package,
  ShoppingBag,
  Settings,
  Activity,
  TrendingUp,
  DollarSign,
  Calendar,
  Bell,
  Plus,
  X
} from 'lucide-react';
import { AddProductForm } from '@/components/AddProductForm';
import { tokenService } from '@/services/tokenService';

const AdminDashboard = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("orders");
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchProducts = async () => {
    setIsLoading(true);
    try {
      const token = tokenService.getAccessToken();
      const response = await fetch(`${import.meta.env.VITE_DJANGO_URL}/products/`, {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': token || '',
          'Origin': window.location.origin
        },
        mode: 'cors'
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        throw new Error(errorData?.detail || 'Failed to fetch products');
      }

      const data = await response.json();
      setProducts(data.results || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to fetch products"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Effect to fetch products when the tab changes to products
  useEffect(() => {
    if (activeTab === 'products') {
      fetchProducts();
    }
  }, [activeTab]);

  // Placeholder data - you'll need to replace these with actual API calls
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalOrders: 0,
    totalProducts: 0,
    revenue: 0,
    recentOrders: [
      { id: 1, customer: 'John Doe', amount: 150, status: 'Completed' },
      { id: 2, customer: 'Jane Smith', amount: 89, status: 'Processing' },
      { id: 3, customer: 'Bob Johnson', amount: 245, status: 'Pending' }
    ]
  });

  useEffect(() => {
    // TODO: Fetch actual statistics from your backend
    const fetchStats = async () => {
      try {
        // Placeholder data - replace with actual API calls
        setStats({
          totalUsers: 150,
          totalOrders: 1250,
          totalProducts: 75,
          revenue: 45231,
          recentOrders: [
            { id: 1, customer: 'John Doe', amount: 150, status: 'Completed' },
            { id: 2, customer: 'Jane Smith', amount: 89, status: 'Processing' },
            { id: 3, customer: 'Bob Johnson', amount: 245, status: 'Pending' }
          ]
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to fetch dashboard statistics",
          variant: "destructive"
        });
      }
    };

    fetchStats();
  }, []);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-1 pt-16"> {/* Add padding top to prevent navbar overlap */}
        <div className="container mx-auto px-4 py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-8"
          >
            <div className="flex items-center justify-between">
              <motion.h1 
                className="text-4xl font-bold"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                Admin Dashboard
              </motion.h1>
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="flex space-x-2"
              >
                <Button size="sm" variant="outline">
                  <Bell className="w-4 h-4 mr-2" />
                  Notifications
                </Button>
                <Button size="sm" variant="outline">
                  <Calendar className="w-4 h-4 mr-2" />
                  Today
                </Button>
              </motion.div>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
              <TabsList className="grid grid-cols-5 gap-4 bg-muted/50 p-1">
                <TabsTrigger value="overview" className="data-[state=active]:bg-background">
                  <Activity className="w-4 h-4 mr-2" />
                  Overview
                </TabsTrigger>
                <TabsTrigger value="users" className="data-[state=active]:bg-background">
                  <Users className="w-4 h-4 mr-2" />
                  Users
                </TabsTrigger>
                <TabsTrigger value="orders" className="data-[state=active]:bg-background">
                  <ShoppingBag className="w-4 h-4 mr-2" />
                  Orders
                </TabsTrigger>
                <TabsTrigger value="products" className="data-[state=active]:bg-background">
                  <Package className="w-4 h-4 mr-2" />
                  Products
                </TabsTrigger>
                <TabsTrigger value="settings" className="data-[state=active]:bg-background">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </TabsTrigger>
              </TabsList>

            <TabsContent value="overview">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">Total Users</p>
                        <h3 className="text-2xl font-bold">{stats.totalUsers}</h3>
                      </div>
                      <Users className="w-8 h-8 text-primary" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">Total Orders</p>
                        <h3 className="text-2xl font-bold">{stats.totalOrders}</h3>
                      </div>
                      <ShoppingBag className="w-8 h-8 text-primary" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">Total Products</p>
                        <h3 className="text-2xl font-bold">{stats.totalProducts}</h3>
                      </div>
                      <Package className="w-8 h-8 text-primary" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">Revenue</p>
                        <h3 className="text-2xl font-bold">$45,231</h3>
                      </div>
                      <Activity className="w-8 h-8 text-primary" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="users">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">User Management</h3>
                  {/* Add user management UI here */}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="orders">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Order Management</h3>
                  {/* Add order management UI here */}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="products">
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h3 className="text-xl font-semibold">Product Management</h3>
                      <Button onClick={() => setShowAddProduct(true)} className="bg-gradient-to-r from-secondary to-primary text-primary-foreground hover:opacity-90">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Product
                      </Button>
                    </div>

                    {showAddProduct ? (
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <h4 className="text-lg font-medium">Add New Product</h4>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => { setShowAddProduct(false); setEditProduct(null); }}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                        <AddProductForm
                          product={editProduct}
                          onSuccess={() => {
                            setShowAddProduct(false);
                            setEditProduct(null);
                            // Refresh products list
                            fetchProducts();
                          }}
                        />
                      </div>
                    ) : (
                      <div className="staggered-animation">
                        <ScrollArea className="h-[700px]">
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4">
                            {products.map((product) => (
                              <motion.div
                                key={product.id}
                                className="product-card rounded-xl overflow-hidden bg-white dark:bg-gray-800 shadow-lg"
                                whileHover={{ y: -5 }}
                                transition={{ duration: 0.2 }}
                              >
                                <div className="relative h-48 overflow-hidden">
                                  <img
                                    src={product.product_image1_url}
                                    alt={product.product_title}
                                    className="product-image w-full h-full object-cover"
                                  />
                                  <div className="absolute top-2 right-2">
                                    <Badge className="bg-primary/90 hover:bg-primary/100">
                                      {product.category}
                                    </Badge>
                                  </div>
                                </div>
                                
                                <div className="p-4 space-y-4">
                                  <div>
                                    <h3 className="text-lg font-semibold tracking-tight mb-1">
                                      {product.product_title}
                                    </h3>
                                    <p className="text-sm text-muted-foreground line-clamp-2">
                                      {product.product_description}
                                    </p>
                                  </div>

                                  <div className="space-y-3">
                                    <h4 className="text-sm font-medium text-muted-foreground">
                                      Variants
                                    </h4>
                                    <div className="grid gap-2">
                                      {product.variants.map((variant) => (
                                        <div 
                                          key={variant.variant_id}
                                          className="flex items-center justify-between p-2 bg-muted/50 rounded-lg text-sm"
                                        >
                                          <span>{variant.weight}g</span>
                                          <span className="font-medium">₹{variant.price}</span>
                                          <span className={cn(
                                            "px-2 py-1 rounded text-xs",
                                            parseInt(variant.stock) > 10 
                                              ? "bg-green-100 text-green-700 dark:bg-green-700/20 dark:text-green-400"
                                              : "bg-red-100 text-red-700 dark:bg-red-700/20 dark:text-red-400"
                                          )}>
                                            Stock: {variant.stock}
                                          </span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>

                                  <div className="pt-4 flex justify-end space-x-2">
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="text-yellow-600 border-yellow-600 hover:bg-yellow-50 dark:hover:bg-yellow-900/20"
                                      onClick={() => {
                                        // Open edit form with product data
                                        setEditProduct(product);
                                        setShowAddProduct(true);
                                        // scroll to form area if needed
                                        window.scrollTo({ top: 0, behavior: 'smooth' });
                                      }}
                                    >
                                      Edit
                                    </Button>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="text-red-600 border-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
                                      onClick={async () => {
                                        if (!confirm('Delete this product?')) return;
                                        try {
                                          const token = tokenService.getAccessToken();
                                          const res = await fetch(`${import.meta.env.VITE_DJANGO_URL}/products/${product.id}/`, {
                                            method: 'DELETE',
                                            credentials: 'include',
                                            headers: {
                                              'Authorization': token || ''
                                            }
                                          });
                                          if (!res.ok) throw new Error('Failed to delete product');
                                          toast({ title: 'Deleted', description: 'Product deleted' });
                                          fetchProducts();
                                        } catch (err) {
                                          console.error('Delete error', err);
                                          toast({ variant: 'destructive', title: 'Error', description: err.message || 'Failed to delete' });
                                        }
                                      }}
                                    >
                                      Delete
                                    </Button>
                                  </div>
                                </div>
                              </motion.div>
                            ))}
                          </div>
                        </ScrollArea>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Admin Settings</h3>
                  {/* Add settings UI here */}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
        </div>
      </main>
      <Footer />
      <Toaster />
    </div>
  );
};

export default AdminDashboard;
