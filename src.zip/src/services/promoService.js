import axios from '../lib/axios';

// Get all promo codes
export const getAllPromoCodes = async () => {
    try {
        const response = await axios.get('/getallpromos');
        
        if (Array.isArray(response.data)) {
            // Only transform active promocodes
            return response.data
                .filter(promo => promo.active)
                .map(promo => ({
                    code: promo.code,
                    discount: parseFloat(promo.discount_value)
                }));
        }
        
        console.warn('Unexpected response format from promo API:', response.data);
        return [];
    } catch (error) {
        console.error('Error fetching promo codes:', error);
        return [];
    }
};

// Apply promo code
export const applyPromoCode = async (code) => {
    try {
        const response = await axios.post(`/apply-promocode?code=${encodeURIComponent(code)}`);
        
        // If the promocode is valid, get its details to show discount
        if (response.data) {
            const detailsResponse = await axios.get('/getallpromos');
            const promoDetails = Array.isArray(detailsResponse.data) 
                ? detailsResponse.data.find(promo => promo.code.toLowerCase() === code.toLowerCase())
                : null;

            if (promoDetails) {
                return {
                    code: promoDetails.code,
                    discount: parseFloat(promoDetails.discount_value)
                };
            }
        }
        throw new Error('Invalid promocode');
    } catch (error) {
        // Handle specific error messages from the backend
        if (error.response?.data) {
            const errorMessage = typeof error.response.data === 'string' 
                ? error.response.data 
                : error.response.data.message;
            throw new Error(errorMessage || 'Failed to apply promocode');
        }
        throw new Error('Failed to apply promocode');
    }
};
