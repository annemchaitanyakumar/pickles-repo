import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { tokenService } from '@/services/tokenService';

export const AddProductForm = ({ onSuccess, product = null }) => {
    const { toast } = useToast();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);

    // Admin check
    useEffect(() => {
        // Use tokenService to obtain user info (mirrors non-sensitive fields to cookies)
        const authData = tokenService.getUserInfo();
        console.log('Initial auth data (from tokenService):', authData);

        if (authData) {
            if ((authData.role || '').toUpperCase() !== 'ADMIN' && (authData.role || '').toUpperCase() !== 'ROLE_ADMIN') {
                toast({
                    variant: "destructive",
                    title: "Access Denied",
                    description: "Only administrators can add products"
                });
                navigate('/');
                return;
            }

            // Validate token presence (in-memory)
            const token = tokenService.getAccessToken();
            if (!token) {
                toast({
                    variant: "destructive",
                    title: "Authentication Error",
                    description: "Please login again"
                });
                navigate('/login');
                return;
            }

            console.log('Admin check passed, token present');
        } else {
            toast({
                variant: "destructive",
                title: "Access Denied",
                description: "Please login as administrator"
            });
            navigate('/login');
        }
    }, [navigate, toast]);

    const [formData, setFormData] = useState({
        category: '',
        product_name: '', // Short name for identification
        product_title: '', // Display title
        product_description: '',
        product_image1: null,
        product_image2: null,
        product_image3: null,
        variants: [
            { weight: '', price: '', stock: '' },
            { weight: '', price: '', stock: '' },
            { weight: '', price: '', stock: '' }
        ]
    });

    // If `product` prop is provided (edit mode), populate form
    useEffect(() => {
        if (!product) return;
        try {
            setFormData({
                category: product.category || '',
                product_name: product.product_name || product.product_title || '',
                product_title: product.product_title || '',
                product_description: product.product_description || '',
                // images: we don't set File objects here; user may re-upload to change
                product_image1: null,
                product_image2: null,
                product_image3: null,
                variants: (product.variants || []).slice(0,3).map(v => ({
                    // keep any existing variant ids for update
                    variant_id: v.variant_id ?? v.id ?? null,
                    weight: v.weight ?? '',
                    price: v.price ?? '',
                    stock: v.stock ?? '',
                    unit: v.unit ?? 'g'
                })).concat(Array.from({ length: Math.max(0, 3 - (product.variants || []).length) }, () => ({ weight: '', price: '', stock: '' })))
            });
        } catch (err) {
            console.error('Failed to populate product into form:', err);
        }
    }, [product]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleImageChange = (e, imageNumber) => {
        const file = e.target.files[0];
        if (file) {
            setFormData(prev => ({
                ...prev,
                [`product_image${imageNumber}`]: file
            }));
        }
    };

    const handleVariantChange = (index, field, value) => {
        setFormData(prev => ({
            ...prev,
            variants: prev.variants.map((v, i) =>
                i === index ? { ...v, [field]: value } : v
            )
        }));
    };

    // Helper function to get the stored auth token
    const getStoredAuthToken = () => {
        try {
            const token = tokenService.getAccessToken();
            if (!token) return null;
            return token.startsWith('Bearer ') ? token.split(' ')[1] : token;
        } catch (error) {
            console.error('Error getting auth token:', error);
            return null;
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            const authData = tokenService.getUserInfo() || {};

            // Normalize role
            const role = (authData.role || '').replace("ROLE_", "") || null;
            if (role !== "ADMIN") {
                throw new Error('Only administrators can add products');
            }
            // Get token using the helper function
            const token = getStoredAuthToken();
            if (!token) throw new Error('No token found');

            // Log token for debugging
            console.log('Auth token being used (raw):', token);
            
            // Validate required fields
            if (!formData.category) throw new Error('Please select a category');
            if (!formData.product_title) throw new Error('Product title is required');
            // For edit mode, product_image1 may be empty (no change). Require an image only on create.
            if (!product && !formData.product_image1) throw new Error('At least one image is required');

            // Prepare variants (only those with any values). Include existing variant ids when present
            const variants = formData.variants
                .filter(v => (v.weight || v.price || v.stock))
                .map((v) => ({
                    variant_id: v.variant_id ?? v.id ?? v.variantId ?? null,
                    weight: v.weight !== undefined && v.weight !== null ? String(v.weight) : '',
                    price: v.price !== undefined && v.price !== null ? String(v.price) : '',
                    stock: v.stock !== undefined && v.stock !== null ? String(v.stock) : '',
                    unit: v.unit ?? 'g'
                }));

            // Convert all fields to strings
            const payload = {
                product_name: String(formData.product_name || formData.product_title).trim(),
                product_title: String(formData.product_title).trim(),
                product_description: String(formData.product_description).trim(),
                category: String(formData.category).trim(),
                variants: variants  // Already converted to strings above
            };

            console.log('Sending payload:', payload);

            // Create form data with everything as text except images
            const formDataToSend = new FormData();
            
            // Add text fields first
            formDataToSend.append('product_name', String(payload.product_name));
            formDataToSend.append('product_title', String(payload.product_title));
            formDataToSend.append('product_description', String(payload.product_description));
            formDataToSend.append('category', String(payload.category));
            
            // Add variants as a single JSON field so backend can parse in multipart requests
            if (payload.variants && payload.variants.length > 0) {
                formDataToSend.append('variants', JSON.stringify(payload.variants));
            }

            // Append images
            if (formData.product_image1) formDataToSend.append('product_image1', formData.product_image1);
            if (formData.product_image2) formDataToSend.append('product_image2', formData.product_image2);
            if (formData.product_image3) formDataToSend.append('product_image3', formData.product_image3);

            // Debug FormData
            console.log('Variants being sent:', payload.variants);
            for (let pair of formDataToSend.entries()) {
                console.log('FormData entry:', pair[0], '=', pair[1]);
            }

            // Decide create vs edit
            const isEdit = Boolean(product && product.id);
            const apiUrl = isEdit
                ? `${import.meta.env.VITE_DJANGO_URL}/products/${product.id}/`
                : `${import.meta.env.VITE_DJANGO_URL}/products/`;

            console.log('Making request to:', apiUrl);
            console.log('With authorization:', token);

            const response = await fetch(apiUrl, {
                method: isEdit ? 'PATCH' : 'POST',
                body: formDataToSend,
                credentials: 'include',
                headers: {
                    'Authorization': `Bearer ${token}`  // token is the raw token string (without 'Bearer ')
                },
                mode: 'cors'
            });

            console.log('Response status:', response.status);

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || errorData.category?.[0] || 'Failed to create product');
            }

            const result = await response.json();
            console.log('Product created:', result);

            toast({
                title: "Success",
                description: "Product created successfully",
            });

            if (onSuccess) onSuccess(result);

            // Reset form
            setFormData({
                category: '',
                product_title: '',
                product_description: '',
                product_image1: null,
                product_image2: null,
                product_image3: null,
                variants: [
                    { weight: '', price: '', stock: '' },
                    { weight: '', price: '', stock: '' },
                    { weight: '', price: '', stock: '' }
                ]
            });
        } catch (error) {
            toast({
                variant: "destructive",
                title: "Error",
                description: error.message
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 gap-6">

                {/* Category */}
                <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select
    value={formData.category}
    onValueChange={(value) => {
        console.log('Selected category:', value);
        // Match Django enum values exactly
        setFormData(prev => ({ ...prev, category: value }));
    }}
    required
>
    <SelectTrigger>
        <SelectValue placeholder="Select category" />
    </SelectTrigger>
    <SelectContent>
        <SelectItem value="VEG">VEG</SelectItem>
        <SelectItem value="NONVEG">NON VEG</SelectItem>
    </SelectContent>
</Select>

                </div>

                {/* Product Name (for identification) */}
                <div className="space-y-2">
                    <Label htmlFor="product_name">Product Name</Label>
                    <Input
                        id="product_name"
                        name="product_name"
                        placeholder="Short identifying name"
                        value={formData.product_name}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Product Title (for display) */}
                <div className="space-y-2">
                    <Label htmlFor="product_title">Product Title</Label>
                    <Input
                        id="product_title"
                        name="product_title"
                        placeholder="Display title"
                        value={formData.product_title}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Description */}
                <div className="space-y-2">
                    <Label htmlFor="product_description">Product Description</Label>
                    <Textarea
                        id="product_description"
                        name="product_description"
                        value={formData.product_description}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Images */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {[1, 2, 3].map((num) => (
                        <div key={num} className="space-y-2">
                            <Label htmlFor={`product_image${num}`}>Product Image {num}</Label>
                            <Input
                                id={`product_image${num}`}
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleImageChange(e, num)}
                                required={num === 1}
                            />
                        </div>
                    ))}
                </div>

                {/* Variants */}
                <div className="space-y-4">
                    <Label>Variants</Label>
                    {formData.variants.map((variant, index) => (
                        <Card key={index} className="p-4">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="space-y--y-2">
                                    <Label>Weight (g)</Label>
                                    <Input
                                        type="number"
                                        value={variant.weight}
                                        onChange={(e) => handleVariantChange(index, 'weight', e.target.value)}
                                        required={index === 0}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Price (₹)</Label>
                                    <Input
                                        type="number"
                                        step="0.01"
                                        value={variant.price}
                                        onChange={(e) => handleVariantChange(index, 'price', e.target.value)}
                                        required={index === 0}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Stock</Label>
                                    <Input
                                        type="number"
                                        value={variant.stock}
                                        onChange={(e) => handleVariantChange(index, 'stock', e.target.value)}
                                        required={index === 0}
                                    />
                                </div>
                            </div>
                        </Card>
                    ))}
                </div>

                {/* Submit */}
                <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-secondary to-primary text-primary-foreground hover:opacity-90"
                    disabled={loading}
                >
                    {loading ? (product ? 'Updating...' : 'Creating...') : (product ? 'Update Product' : 'Create Product')}
                </Button>
            </div>
        </form>
    );
};

export default AddProductForm;